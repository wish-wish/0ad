# libicu
libicu for android NDK compile
